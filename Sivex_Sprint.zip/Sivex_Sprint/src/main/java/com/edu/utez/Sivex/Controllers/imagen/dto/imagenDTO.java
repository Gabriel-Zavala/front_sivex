package com.edu.utez.Sivex.Controllers.imagen.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class imagenDTO {
    private long id;
    private String imageName;
    private byte[] imageData;
}
