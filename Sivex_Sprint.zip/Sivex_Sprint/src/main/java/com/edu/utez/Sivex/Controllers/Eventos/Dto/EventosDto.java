package com.edu.utez.Sivex.Controllers.Eventos.Dto;

import com.edu.utez.Sivex.Models.Eventos.BeanEventos;
import com.edu.utez.Sivex.Models.Usuario.BeanUsuario;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class EventosDto {
    private long  id;
    private String nombre;
    private String descripcion;
    private String fecha;


    public BeanEventos toEntity(){
        return new BeanEventos(nombre,descripcion,fecha);
    }
}
