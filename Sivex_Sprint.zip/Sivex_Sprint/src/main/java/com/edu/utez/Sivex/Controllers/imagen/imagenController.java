package com.edu.utez.Sivex.Controllers.imagen;

import com.edu.utez.Sivex.Models.imagen.imagenBean;
import com.edu.utez.Sivex.Models.imagen.imagenRepository;
import lombok.AllArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

@RestController
@RequestMapping("api/Sivex/Imagen")
@CrossOrigin({"*"})
@AllArgsConstructor
public class imagenController {
    private final imagenRepository imageRepository;
    private static final String UPLOAD_DIR = "D:\\tareas"; // Directorio de almacenamiento de imágenes

    @PostMapping("/subir_imagen")
    public ResponseEntity<String> handleImageUpload(@RequestParam("image") MultipartFile image,
                                                    @RequestParam("imageName") String imageName) {
        // Verificar si se recibió la imagen y el nombre
        if (image.isEmpty() || StringUtils.isEmpty(imageName)) {
            return ResponseEntity.badRequest().body("Por favor seleccione una imagen y nombre");
        }

        // Verificar el tipo de archivo
        if (!Objects.requireNonNull(image.getContentType()).startsWith("image")) {
            return ResponseEntity.badRequest().body("Por favor seleccione una imagen válida");
        }

        try {
            // Guardar la imagen en el servidor
            String imagePath = UPLOAD_DIR + File.separator + imageName;
            File dest = new File(imagePath);
            image.transferTo(dest);

            // Guardar la información de la imagen en la base de datos
            imagenBean imageBean = new imagenBean();
            imageBean.setImageName(imageName);
            imageBean.setImagePath(imagePath);
            imageRepository.save(imageBean);

            return ResponseEntity.ok("Imagen subida exitosamente");
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error al subir la imagen");
        }
    }

    @GetMapping("/imagen/{imageName}")
    public ResponseEntity<Resource> getImage(@PathVariable String imageName) {
        // Ruta donde se almacenan las imágenes
        String imagePath = UPLOAD_DIR + File.separator + imageName;

        // Cargar la imagen como un recurso
        Path imageFilePath = Paths.get(imagePath);
        Resource resource;
        try {
            resource = new UrlResource(imageFilePath.toUri());
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.notFound().build();
        }

        // Devolver la imagen como respuesta
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}