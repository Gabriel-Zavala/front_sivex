package com.edu.utez.Sivex.Controllers.Espacios.dto;

import com.edu.utez.Sivex.Models.Espacios.BeanEspacios;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EspaciosDto {
    private long  id;
    private Boolean  status;
    private String tamano;
    private String servicios;
    private Long cant;
    private Long precio;

    public BeanEspacios toEntity(){
        return new BeanEspacios(status,tamano,servicios,cant, precio);
    }
}
