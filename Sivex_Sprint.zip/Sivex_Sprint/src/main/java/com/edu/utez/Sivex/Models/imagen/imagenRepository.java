package com.edu.utez.Sivex.Models.imagen;

import com.edu.utez.Sivex.Models.rol.RolBean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface imagenRepository   extends JpaRepository<imagenBean, Long> {
    List<imagenBean> findByImageName(String imageName);

}
