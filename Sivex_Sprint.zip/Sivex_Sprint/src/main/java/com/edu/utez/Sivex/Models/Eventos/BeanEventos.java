package com.edu.utez.Sivex.Models.Eventos;

import com.edu.utez.Sivex.Models.Historial.BeanHistorial;
import com.edu.utez.Sivex.Models.Usuario.BeanUsuario;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "eventos")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class BeanEventos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long  id;
    @Column(length = 100, nullable = false)
    private String nombre;
    @Column(length = 225, nullable = false)
    private String descripcion;
    @Column(length = 225, nullable = false)
    private String fecha;

    public BeanEventos(String nombre, String descripcion, String fecha) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }



}
