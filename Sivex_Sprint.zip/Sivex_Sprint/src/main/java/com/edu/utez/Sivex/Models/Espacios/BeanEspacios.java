package com.edu.utez.Sivex.Models.Espacios;

import com.edu.utez.Sivex.Models.Historial.BeanHistorial;
import com.edu.utez.Sivex.Models.Usuario.BeanUsuario;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "espacios")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BeanEspacios {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long  id;
    @Column(columnDefinition = "BOOL DEFAULT true")
    private Boolean  status;
    @Column(length = 225, nullable = false)
    private String tamano;
    @Column(length = 225, nullable = false)
    private String servicios;
    @Column(nullable = false)
    private Long cant;
    @Column(nullable = false)
    private Long precio;

    public BeanEspacios(Boolean status, String tamano, String servicios, Long cant, Long precio) {
        this.status = status;
        this.tamano = tamano;
        this.servicios = servicios;
        this.cant = cant;
        this.precio = precio;
    }

    @ManyToOne(cascade = CascadeType.ALL,optional = true)
    @JoinColumn(name = "usuario_id")
    private BeanUsuario beanUsuario;
}
