package com.edu.utez.Sivex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SivexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SivexApplication.class, args);
	}

}
