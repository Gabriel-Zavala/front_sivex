package com.edu.utez.Sivex.Controllers.Usuario.dto;

import com.edu.utez.Sivex.Models.Usuario.BeanUsuario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioDto {
    private long  id;
    private String Correo;
    private String password;

    public BeanUsuario toEntity(){
        return new BeanUsuario(Correo,password);
    }
}
