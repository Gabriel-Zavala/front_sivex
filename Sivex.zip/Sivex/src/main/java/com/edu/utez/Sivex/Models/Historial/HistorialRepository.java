package com.edu.utez.Sivex.Models.Historial;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialRepository extends JpaRepository<BeanHistorial, Long> {
}
