package com.edu.utez.Sivex.Models.Servicios;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ServiciosRepository extends JpaRepository<BeanServicios, Long>{
    Optional<BeanServicios> findByNombre(String nombre);
}
