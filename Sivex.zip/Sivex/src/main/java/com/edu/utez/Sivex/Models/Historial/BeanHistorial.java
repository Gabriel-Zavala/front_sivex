package com.edu.utez.Sivex.Models.Historial;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "historial")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BeanHistorial {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(length = 100, nullable = false)
    private String eveto;
    @Column(columnDefinition = "DATE", nullable=false)
    private LocalDate fecha;
    @Column(nullable = false)
    private Double precio;
    //espacio es un atributo que se obtendra del beanEspacio
}
