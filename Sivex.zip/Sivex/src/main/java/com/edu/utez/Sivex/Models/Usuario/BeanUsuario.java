package com.edu.utez.Sivex.Models.Usuario;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="usuario")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BeanUsuario{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long  id;
    @Column(length = 100,nullable = false)
    private String Correo;
    @Column(length = 100, nullable= false)
    private String password;

    public BeanUsuario(String correo, String password) {
        Correo = correo;
        this.password = password;
    }
}
