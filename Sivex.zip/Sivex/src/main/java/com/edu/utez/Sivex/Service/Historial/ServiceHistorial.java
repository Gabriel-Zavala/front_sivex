package com.edu.utez.Sivex.Service.Historial;

public class ServiceHistorial {
}
