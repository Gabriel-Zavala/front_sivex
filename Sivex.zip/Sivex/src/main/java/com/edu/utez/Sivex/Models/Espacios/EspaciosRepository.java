package com.edu.utez.Sivex.Models.Espacios;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EspaciosRepository  extends JpaRepository<BeanEspacios, Long> {
    Optional<BeanEspacios> findByName(String name);
}
