import { useEffect, useState } from "react"
import { Button, Card, CardBody, CardHeader, Container, Form, Modal, Row } from "react-bootstrap";
import Swal from "sweetalert2";
import Navbar_A from "../Router/Navbar_A";
import Axios  from "axios";

export const Eventos_A=()=>{

    const [modalShow, setModalShow] = useState(false);

    const[Eventos,setEventos]=useState([])
    const[Nombre,setNombre]=useState('')
    const[Descripcion,setDesc]=useState('')
    const[Fecha, setfecha]=useState('')

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [editNombre, setEditNombre] = useState('');
    const [editDescripcion, setEditDescripcion] = useState('');
    const [editFecha, setEditFecha] = useState('');
    const [editId, setEditId] = useState(null);
    const [showEditModal, setShowEditModal] = useState(false);

    const Datos = async () => {
        try {
          const respuesta = await Axios.get('http://localhost:8080/api/Sivex/eventos/Registro');
          console.log('Respuesta del servidor:', respuesta.data.data);
          setEventos(respuesta.data.data);
        } catch (error) {
          console.log('Error al obtener los usuarios:', error);
        }
      };

    useEffect(() => {
        Datos();
      }, []);

    const EnviarG=async(evento)=>{
        evento.preventDefault();
        if (Nombre!='' && Descripcion!='') {
            try {
                const respuesta = await Axios.post('http://localhost:8080/api/Sivex/eventos/',
                {
                    descripcion: Descripcion,
                    nombre: Nombre,
                    fecha:Fecha
                })
                console.log('Respuesta del servidor:', respuesta.data);
                Swal.fire({
                title: "Evento Registrado",
                text: "Guardado exitoso",
                icon: "success"
                });
                Datos()
            } catch (error) {
                console.log('Error al enviar datos:', error);
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "Ocurrio un Error",
                });
            }
        }else{
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "Verifique los datos",
            })
        }
    }

    
    
    const EliminarEvento = async (id) => {
        console.log('El id que llego es: '+id)
        const confirmacion = await Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esta acción no se puede revertir',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminarlo'
        });
    
        if (confirmacion.isConfirmed) {
            try {
                await Axios.delete(`http://localhost:8080/api/Sivex/eventos/Delete/${id}`);
                await Swal.fire('¡Eliminado!', 'El evento ha sido eliminado', 'success');
                Datos();
            } catch (error) {
                console.log('Error al eliminar el evento:', error);
                Swal.fire('Error', 'Ocurrió un error al eliminar el evento', 'error');
            }
        }
    };
    
    const abrirModalEdicion = (id, nombre, descripcion, fecha) => {
        setEditId(id);
        setEditNombre(nombre);
        setEditDescripcion(descripcion);
        setEditFecha(fecha)
        setShowEditModal(true);
    };

    const actualizarServicio = async (e) => {
        e.preventDefault();
        try {
            const respuesta = await Axios.put(`http://localhost:8080/api/Sivex/eventos/Actualizar/${editId}`, {
                nombre: editNombre,
                descripcion:editDescripcion,
                fecha:editFecha
            });
            console.log('Respuesta del servidor:', respuesta.data);
            setShowEditModal(false);
            Datos();
        } catch (error) {
            console.log('Error al actualizar el servicio:', error);
        }
    };

    

    return(
        <div style={{backgroundColor:'#E5E5E5', height:'100vh',textAlign:"center"}} >
            <div><Navbar_A/></div>
            <h1>Eventos</h1>
            <Row>
                {Eventos.length>0 ? (Eventos.map((item, index)=>{
                return(
                    <Card key={index} style={{ width: '18rem', margin:10 }} >
                        <CardBody>
                            <Card.Title>{item.nombre}</Card.Title>
                            <Card.Text>{item.descripcion}</Card.Text>
                        </CardBody>
                        <Card.Footer >
                           <Button style={{marginLeft:10}} variant="danger" type="submit" onClick={()=>{EliminarEvento(item.id)}} >Eliminar</Button>
                           <Button style={{marginLeft:10}} variant="warning" onClick={() => abrirModalEdicion(item.id, item.nombre,item.descripcion, item.fecha)}>Editar</Button>
                        </Card.Footer>
                    </Card>
                    )
                })):(<p>No hay eventos todavia</p>)}
            </Row>
            
            <div style={{justifyContent:"center", alignItems:"center"}}><Button variant="primary" onClick={handleShow}>Añadir</Button></div>
            
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>Registrar Eventos</Modal.Title>
                </Modal.Header>
                <Form onSubmit={EnviarG}>
                <Modal.Body>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Nombre:</Form.Label>
                        <Form.Control type="Text" placeholder=""  onChange={evento=>setNombre(evento.target.value)} />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                        <Form.Label>Descripcion:</Form.Label>
                        <Form.Control as="textarea" rows={3}  onChange={evento=>setDesc(evento.target.value)}/>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Fecha:</Form.Label>
                        <Form.Control type="Text" placeholder=""  onChange={evento=>setfecha(evento.target.value)} />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="danger" onClick={handleClose}>Cerrar</Button>
                <Button variant="success" type="submit" onClick={handleClose}>Guardar</Button>
                </Modal.Footer>
                </Form>
            </Modal>

            <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
            <Modal.Header closeButton>
                <Modal.Title>Editar Servicio</Modal.Title>
            </Modal.Header>
            <Form onSubmit={actualizarServicio}>
                <Modal.Body>
                    <Form.Group controlId="formEditNombre">
                        <Form.Label>Nombre:</Form.Label>
                        <Form.Control type="text" value={editNombre} onChange={(e) => setEditNombre(e.target.value)} />
                    </Form.Group>
                    <Form.Group controlId="formEditNombre">
                        <Form.Label>Descripcion:</Form.Label>
                        <Form.Control as="textarea" rows={3}  value={editDescripcion} onChange={(e) => setEditDescripcion(e.target.value)} />
                    </Form.Group>
                    <Form.Group controlId="formEditNombre">
                        <Form.Label>Fecha:</Form.Label>
                        <Form.Control type="text" value={editFecha} onChange={(e) => setEditFecha(e.target.value)} />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowEditModal(false)}>
                        Cerrar
                    </Button>
                    <Button variant="primary" type="submit">
                        Guardar Cambios
                    </Button>
                </Modal.Footer>
            </Form>
            </Modal>
        </div>
    );
}
