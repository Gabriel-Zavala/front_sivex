import { Button, Container, Form, Modal, Row, Table } from "react-bootstrap";

import Navbar_A from "../Router/Navbar_A";
import { useEffect, useState } from "react";
import  Axios  from "axios";
import Swal from "sweetalert2";

export const Servicios=()=>{

    const [modalShow, setModalShow] = useState(false);
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [editNombre, setEditNombre] = useState('');
    const [editId, setEditId] = useState(null);
    const [showEditModal, setShowEditModal] = useState(false);

    const[Nombre,setNombre]=useState('')
    const[Servicios, setServicios]=useState("")

    const Datos = async () => {
        try {
          const respuesta = await Axios.get('http://localhost:8080/api/Sivex/servicios/Registro');
          console.log('Respuesta del servidor:', respuesta.data.data);
          setServicios(respuesta.data.data);
        } catch (error) {
          console.log('Error al obtener los datos:', error);
        }
      };

    useEffect(() => {
        Datos();
      }, []);

    const Enviar=async(evento)=>{
        evento.preventDefault();
        if (Nombre!='') {
            try {
                const respuesta = await Axios.post('http://localhost:8080/api/Sivex/servicios/',
                {
                    nombre:Nombre
                })
                console.log('Respuesta del servidor:', respuesta.data);
                Swal.fire({
                title: "Evento Registrado",
                text: "Guardado exitoso",
                icon: "success"
                });
                Datos()
            } catch (error) {
                console.log('Error al enviar datos:', error);
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "Ocurrio un Error",
                });
            }
        }else{
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "Verifique los datos",
            })
        }
    }

    const abrirModalEdicion = (id, nombre) => {
        setEditId(id);
        setEditNombre(nombre);
        setShowEditModal(true);
    };

    const actualizarServicio = async (e) => {
        e.preventDefault();
        try {
            const respuesta = await Axios.put(`http://localhost:8080/api/Sivex/servicios/Actualizar/${editId}`, {
                nombre: editNombre
            });
            console.log('Respuesta del servidor:', respuesta.data);
            setShowEditModal(false);
            Datos();
        } catch (error) {
            console.log('Error al actualizar el servicio:', error);
        }
    };

    
    
    const EliminarServicio = async (id) => {
        const confirmacion = await Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esta acción no se puede revertir',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminarlo'
        });
    
        if (confirmacion.isConfirmed) {
            try {
                await Axios.delete(`http://localhost:8080/api/Sivex/servicios/Delete/${id}`);
                await Swal.fire('¡Eliminado!', 'El servicio ha sido eliminado', 'success');
                Datos();
            } catch (error) {
                console.log('Error al eliminar el evento:', error);
                Swal.fire('Error', 'Ocurrió un error al eliminar el evento', 'error');
            }
        }
    };
    

    return(
        <div style={{backgroundColor:'#E5E5E5', height:'100vh', flex:1}}>
            <Row>
                <div><Navbar_A/></div>
                <Table striped style={{ margin:10}}>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    {Servicios.length>0 ?(Servicios.map((item, index)=>{
                        return(
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{item.nombre}</td>
                                <td>
                                    <Button style={{marginLeft:10}} variant="danger" type="submit"  onClick={()=>{EliminarServicio(item.id)}} >Eliminar</Button>
                                    <Button style={{marginLeft:10}} variant="warning" type="submit" onClick={()=> abrirModalEdicion(item.id, item.nombre)}>Editar</Button>
                                </td>
                            </tr>
                        )
                        
                    })):(
                        <tr>
                            <td colSpan="3">No hay servicios registrados</td>
                        </tr>
                    )}
                    </tbody>
                </Table>
            </Row>
            <div style={{justifyContent:"center", alignItems:"center"}}><Button variant="primary" onClick={handleShow}>Añadir</Button></div>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>Registrar Servicios</Modal.Title>
                </Modal.Header>
                <Form onSubmit={Enviar}>
                <Modal.Body>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Nombre:</Form.Label>
                        <Form.Control type="Text" placeholder=""  onChange={evento=>setNombre(evento.target.value)} />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="danger" onClick={handleClose}>Cerrar</Button>
                <Button variant="success" type="submit" onClick={handleClose}>Guardar</Button>
                </Modal.Footer>
                </Form>
            </Modal>

            <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
            <Modal.Header closeButton>
                <Modal.Title>Editar Servicio</Modal.Title>
            </Modal.Header>
            <Form onSubmit={actualizarServicio}>
                <Modal.Body>
                    <Form.Group controlId="formEditNombre">
                        <Form.Label>Nombre:</Form.Label>
                        <Form.Control type="text" value={editNombre} onChange={(e) => setEditNombre(e.target.value)} />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowEditModal(false)}>
                        Cerrar
                    </Button>
                    <Button variant="primary" type="submit">
                        Guardar Cambios
                    </Button>
                </Modal.Footer>
            </Form>
        </Modal>

        </div>
    );
}