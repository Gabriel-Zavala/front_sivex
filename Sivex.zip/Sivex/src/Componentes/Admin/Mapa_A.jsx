import React, { useState } from "react";
import axios from "axios";
import Navbar_A from "../Router/Navbar_A";

export const Mapa_A = () => {
    const [image, setImage] = useState(null);
    const [imageName, setImageName] = useState("");
    const [imageUrl, setImageUrl] = useState(null);

    const handleImageChange = (event) => {
        const selectedImage = event.target.files[0];
        setImage(selectedImage);
    };

    const handleNameChange = (event) => {
        setImageName(event.target.value);
    };

    const handleUploadImage = () => {
        if (!image || !imageName) {
            console.log("Por favor seleccione una imagen y nombre");
            return;
        }

        const formData = new FormData();
        formData.append("image", image);
        formData.append("imageName", imageName);

        axios.post("http://localhost:8080/api/Sivex/Imagen/subir_imagen", formData)
            .then((response) => {
                console.log("Imagen subida exitosamente:", response.data);
                // Actualizar la URL de la imagen para mostrarla al usuario
                setImageUrl(response.data.imageUrl);
            })
            .catch((error) => {
                console.error("Error al subir la imagen:", error);
                // Manejar errores
            });
    };

    return (
        <div style={{ backgroundColor: "#E5E5E5", height: "100vh" }}>
            <Navbar_A />
            <div style={{ textAlign: "center", marginTop: 20 }}>
                {/* Input para seleccionar la imagen */}
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    style={{ marginBottom: 10 }}
                />
                <br />
                {/* Input para ingresar el nombre de la imagen */}
                <input
                    type="text"
                    placeholder="Nombre de la imagen"
                    value={imageName}
                    onChange={handleNameChange}
                    style={{ marginBottom: 10 }}
                />
                <br />
                {/* Botón para subir la imagen */}
                <button onClick={handleUploadImage}>Subir Imagen</button>
                <br />
                {/* Mostrar la imagen subida si existe */}
                {imageUrl && (
                    <div style={{ marginTop: 20 }}>
                        <h2>Imagen Subida:</h2>
                        <img src={imageUrl} alt="Imagen Subida" style={{ maxWidth: "100%" }} />
                    </div>
                )}
            </div>
        </div>
    );
};
