import { Button, Card, Container, Row } from "react-bootstrap"
import NavBar from "../Router/NavBar"
import { useEffect, useState } from "react";
import  Axios from "axios";

export const Eventos=()=>{

    const[Eventos,setEventos]=useState([])

    const Datos = async () => {
        try {
          const respuesta = await Axios.get('http://localhost:8080/api/Sivex/eventos/Registro');
          console.log('Respuesta del servidor:', respuesta.data.data);
          setEventos(respuesta.data.data);
        } catch (error) {
          console.log('Error al obtener los usuarios:', error);
        }
      };

    useEffect(() => {
        Datos();
      }, []);

    return(
        <div style={{backgroundColor:'#E5E5E5', height:'100vh'}}>
           <Row>
            <div><NavBar/></div> 
            <Row style={{ textAlign:"center"}}>
                <h1>Eventos</h1>
            </Row>
            {Eventos.length>0 ? (Eventos.map((item, index)=>{
                return(
                    <Card key={index} style={{ width: '18rem', margin:20}}>
                    <Card.Body>
                        <Card.Title>{item.nombre}</Card.Title>
                        <Card.Text>
                                Descripcion: {item.descripcion}
                        </Card.Text>
                        <Card.Text>
                                Fecha: {item.fecha}
                        </Card.Text>
                        <Button style={{backgroundColor:'#129E9E',}} variant="success">Espacios Disponibles</Button>
                    </Card.Body>
                    </Card>
                )
            })):(<p>No hay eventos todavia</p>)}
                
           </Row>
        </div>
    )
}