import { useEffect, useState } from "react";
import { Button, Card, CardBody, Col, Form, Row } from "react-bootstrap";
import { Link,useNavigate} from "react-router-dom";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import  Axios  from "axios";

export const InicioSesion=()=>{

    const navegacion=useNavigate()
    const [usuarios, setUsuarios] = useState([]);
    const[correo,setCorreo]=useState('');
    const[contraseña,setContra]=useState('');
    const [mostrarContraseña, setMostrarContraseña] = useState(false);

    const User='http://localhost:8080/api/Sivex/usuario/Registro'    

    useEffect(() => {
        Datos();
    }, []);

  const Datos = async () => {
    try {
      const respuesta = await Axios.get('http://localhost:8080/api/Sivex/usuario/Registro');
      setUsuarios(respuesta.data.data);
      console.log(respuesta.data.data)
    } catch (error) {
      console.error('Error al obtener los usuarios:', error);
    }
  };

    const Enviar= async (evento)=>{
        evento.preventDefault();

        for (let index = 0; index < usuarios.length; index++) {
            const element = usuarios[index];
            console.log()
            if (element.correo == correo && element.password == contraseña && element.rol == "Usuario") {
                Swal.fire({
                    title: "Iniciando sesion...",
                    text: "todo bien :D",
                    icon: "success"
                })
                navegacion('/Eventos')
            }else if(element.correo == correo && element.password == contraseña && element.rol == "Administrador"){
                Swal.fire({
                    title: "Iniciando sesion...",
                    text: "todo bien :D",
                    icon: "success"
                })
                navegacion('/Eventos-Admin')
            }else{
                    Swal.fire({
                    icon: "error",
                    title: "Acceso denegado",
                    text: "El correo y/o contraseña incorrectos",
                  });
                }
        }
    }

    return(
      <div  className="d-flex justify-content-center align-items-center" style={{height:'100vh'}}>
        <Row>
        
            <Row style={{justifyContent: "center", alignItems:"center", textAlign:"center"}}>
                <img src="src\Img\Logo-utez.png" style={{width:200, height:100, marginTop:10}}/>
                <h1>Sivex</h1>
            </Row>

            <Row style={{justifyContent: "center", alignItems:"center"}}>
                <Col md={6}>
                    <Card style={{justifyContent: "center", alignItems:"center", backgroundColor:"#F5ECEC" }}>
                        <CardBody>
                            <Form onSubmit={Enviar}>

                                <Form.Group className="mb-3" controlId="formGroupEmail">
                                    <Form.Label>Correo:</Form.Label>
                                    <Form.Control type="email" placeholder="Correo" onChange={evento=>setCorreo(evento.target.value)} required/>
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="formGroupPassword">
                                    <Form.Label>Contraseña: </Form.Label>
                                    <div className="d-flex align-items-center">
                                        <Form.Control type={mostrarContraseña ? "text" : "password"} placeholder="*****" onChange={evento => setContra(evento.target.value)} required />
                                        <Button variant="outline-secondary" onClick={() => setMostrarContraseña(!mostrarContraseña)}>
                                            <FontAwesomeIcon icon={mostrarContraseña ? faEyeSlash : faEye} />
                                        </Button>
                                    </div>
                                </Form.Group>
                                <Button style={{backgroundColor:'#191970', width:250}} type="submit">Iniciar Sesion</Button>
                            </Form> 
                        </CardBody>
                    </Card>

                    <Card style={{justifyContent: "center", alignItems:"center", backgroundColor:"#F5ECEC", marginTop:20 }}>
                        <CardBody>
                              <Card.Text>¿Eres nuevo? <Link to={'/Registro'}>Registrate</Link></Card.Text>
                        </CardBody>
                    </Card>

                </Col>
            </Row>

        </Row>
      </div>  
    );
}