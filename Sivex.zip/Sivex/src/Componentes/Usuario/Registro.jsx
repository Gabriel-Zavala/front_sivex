import { useState } from "react";
import { Button, Card, CardBody, Col, Container, Form, Row } from "react-bootstrap";
import Swal from "sweetalert2";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import { Link,useNavigate} from "react-router-dom";
import  Axios  from "axios";

export const Registro=()=>{

    const navegacion=useNavigate();

    const[correo,setCorreo]=useState('');
    const[contraseña,SetContra]=useState('');
    const[Ccorreo,setCcorreo]=useState('');
    const[Ccontraseña,SetCcontra]=useState('');
    const [mostrarContraseña, setMostrarContraseña] = useState(false);
    const [mostrarCContraseña, setMostrarCContraseña] = useState(false);

    const Enviar=async(evento)=>{
        evento.preventDefault();
        if (correo==Ccorreo && contraseña==Ccontraseña) {
            try {
                const respuesta= await Axios.post('http://localhost:8080/api/Sivex/usuario/',
            {
                correo:correo,
                password:contraseña,
                status:true,
                rol: "Usuario"
            })
            console.log('Respuesta del servidor:', respuesta.data);
            Swal.fire({
                title: "Usuario registrado",
                text: "El registro se relizo correctamente",
                icon: "success"
            });
            navegacion('/')
            } catch (error) {
                console.log('Error al enviar datos:', error);
               Swal.fire({
                icon: "error",
                title: "Usuario no registrado",
                text: "Algo salio mal",
              }); 
            }
            
        }else{
            Swal.fire({
                icon: "error",
                title: "Usuario no registrado",
                text: "Los datos no coinciden",
              });
        }
    }

    return(
        <Container className="d-flex justify-content-center align-items-center" style={{height:'100vh'}}>
        <Row>
            <Row style={{justifyContent: "center", alignItems:"center",textAlign:"center" }}>
                <img src="src\Img\Logo-utez.png" style={{width:200, height:100, marginTop:10}}/>
                <h1>Registro</h1>
            </Row>
            
            <Row style={{justifyContent: "center", alignItems:"center"}}>
                <Col md={6}>
                    <Card style={{alignItems:"center", backgroundColor:"#F5ECEC" }}>
                        <CardBody>
                            <Form onSubmit={Enviar} >
                                <Form.Group className="mb-3" controlId="correo">
                                    <Form.Label>Correo:</Form.Label>
                                    <Form.Control type="email" placeholder="" onChange={evento=>setCorreo(evento.target.value)} required />
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="Ccorreo">
                                    <Form.Label>Confirmar Correo:</Form.Label>
                                    <Form.Control type="email" placeholder="" onChange={evento=>setCcorreo(evento.target.value)} required />
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="contraseña">
                                    <Form.Label>Contraseña: </Form.Label>
                                    <div className="d-flex align-items-center">
                                        <Form.Control type={mostrarContraseña ? "text" : "password"}  placeholder="******" onChange={evento=>SetCcontra(evento.target.value)} required />
                                        <Button variant="outline-secondary" onClick={() => setMostrarContraseña(!mostrarContraseña)}>
                                            <FontAwesomeIcon icon={mostrarContraseña ? faEyeSlash : faEye} />
                                        </Button>
                                    </div>
                                </Form.Group>
                                <Form.Group className="mb-3" controlId="Ccontra">
                                    <Form.Label>Confirmar Contraseña: </Form.Label>
                                    <div className="d-flex align-items-center">
                                        <Form.Control type={mostrarCContraseña ? "text" : "password"} placeholder="******" onChange={evento=>SetContra(evento.target.value)} />
                                        <Button variant="outline-secondary" onClick={() => setMostrarCContraseña(!mostrarCContraseña)}>
                                            <FontAwesomeIcon icon={mostrarCContraseña ? faEyeSlash : faEye} />
                                        </Button>
                                    </div>
                                </Form.Group>
                                <Button style={{backgroundColor:'#129E9E', width:250}} variant="success" type="submit">Enviar</Button>
                            </Form>
                        </CardBody>
                    </Card>
                    <div style={{margin:20,textAlign:"center" }}>¿Ya tienes cuenta? <a style={{color:'#129E9E'}}  href='/'>Inicia sesion</a></div>
                </Col>
            </Row>
        </Row>
      </Container>    
    );
}