import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavBar from '../Router/NavBar';

export const Mapa = () => {
    const [imageUrl, setImageUrl] = useState('');

    useEffect(() => {
        const fetchImage = async () => {
            try {
                // Realizar la solicitud al backend para obtener la imagen
                const response = await axios.get('http://localhost:8080/api/Sivex/D:\tareas\asd');

                // Obtener la URL de la imagen desde la respuesta
                const imageUrl = response.data.imageUrl;
                setImageUrl(imageUrl);
            } catch (error) {
                console.error('Error al obtener la imagen:', error);
            }
        };

        fetchImage();
    }, []);

    return (
        <div style={{ backgroundColor: '#E5E5E5', height: '100vh' }}>
            <NavBar />
            <h1>Aqui va el mapa</h1>
            {imageUrl && <img src={imageUrl} alt="Imagen del mapa" />}
        </div>
    );
};
