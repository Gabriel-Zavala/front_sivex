import React from 'react'
import { Navbar,Nav,Container,Row} from "react-bootstrap";

const Navbar_A = () => {
  return (
    <div>
    <Navbar bg="light" data-bs-theme="light">
        <Container>
          <Navbar.Brand href="/Eventos-Admin">SIVEX</Navbar.Brand>
          <Nav className="me-auto">
          <Nav.Link href="/Eventos-Admin">Eventos</Nav.Link>
            <Nav.Link href="/Servicios-Admin">Servicios</Nav.Link>
            <Nav.Link href="/Mapa-Admin">Imagen</Nav.Link>
            <Nav.Link href="/">Cerrar Sesion</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </div>
  )
}

export default Navbar_A