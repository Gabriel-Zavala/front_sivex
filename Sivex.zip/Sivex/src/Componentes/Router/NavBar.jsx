import React from 'react'
import '../../index.css'
import { Navbar,Nav,Container,Row} from "react-bootstrap";

const NavBar = () => {
  return (
    <div>
    <Navbar bg="light" data-bs-theme="light">
        <Container>
          <Navbar.Brand href="/Eventos">SIVEX</Navbar.Brand>
          <Nav className="me-auto">
          <Nav.Link href="/Eventos">Eventos</Nav.Link>
            <Nav.Link href="/Historial">Historial</Nav.Link>
            <Nav.Link href="/Mapa">Mapa</Nav.Link>
            <Nav.Link href="/">Cerrar Sesion</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </div>
  )
}

export default NavBar

/*
      <nav className="navbar">
      <div className="navbar-brand">
        <a href="/" className="navbar-logo">Logo</a>
      </div>
      <ul className="navbar-nav">
        <li className="nav-item">
          <a href="/" className="nav-link">Inicio</a>
        </li>
        <li className="nav-item">
          <a href="/acerca" className="nav-link">Acerca</a>
        </li>
        <li className="nav-item">
          <a href="/servicios" className="nav-link">Servicios</a>
        </li>
        <li className="nav-item">
          <a href="/contacto" className="nav-link">Contacto</a>
        </li>
      </ul>
    </nav>
*/