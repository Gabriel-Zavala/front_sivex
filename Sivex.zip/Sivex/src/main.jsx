import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom'
import { InicioSesion } from './Componentes/Usuario/InicioSesion'
import { Registro } from './Componentes/Usuario/Registro'
import { Historial } from './Componentes/Usuario/Historial'
import { Eventos } from './Componentes/Usuario/Eventos'
import { Eventos_A } from './Componentes/Admin/Eventos_A'
import { Servicios } from './Componentes/Admin/Servicios'
import { Mapa } from './Componentes/Usuario/Mapa';
import { Mapa_A } from './Componentes/Admin/Mapa_A';

ReactDOM.createRoot(document.getElementById('root')).render(
  <Router>
    <Routes>
      <Route path='/' Component={InicioSesion} />
      <Route path='/Registro' element={<Registro/>} />
      <Route path='/Historial' Component={Historial} />
      <Route path='/Eventos' Component={Eventos} />
      <Route path='/Mapa' Component={Mapa} />
      <Route path='/Eventos-Admin' Component={Eventos_A} />
      <Route path='/Servicios-Admin' Component={Servicios} />
      <Route path='/Mapa-Admin' Component={Mapa_A} />
    </Routes>
  </Router>
)
